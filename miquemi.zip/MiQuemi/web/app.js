const form = document.querySelector('#download-form');
const urlInput = document.querySelector('#url');
const submit = document.querySelector('#submit');
const panel = document.querySelector('#status-panel');
const statusText = document.querySelector('#status');
const progress = document.querySelector('#progress');
const save = document.querySelector('#save');
const saveHelp = document.querySelector('#save-help');
const dialog = document.querySelector('#access-dialog');
const api = (window.MIQUEMI_API || '').replace(/\/$/, '');
let accessCode = '';
try { accessCode = localStorage.getItem('miquemi-access') || ''; } catch {}
let releaseAt = 0;
let waitTimer;
let resumeAfterAccess = () => form.requestSubmit();

function renderLimits(limits) {
  document.querySelector('#limits-summary').textContent =
    `Hasta ${limits.maxMinutes} min · ${limits.maxMB} MB por archivo · Uno a la vez`;
  document.querySelector('#limits-availability').textContent =
    `${limits.availableFiles} de ${limits.maxFiles} lugares disponibles. Cada enlace dura ${limits.fileMinutes} minutos.`;
  clearInterval(waitTimer);
  releaseAt = limits.retryAfter ? Date.now() + limits.retryAfter * 1000 : 0;
  const wait = document.querySelector('#limit-wait');
  wait.hidden = !releaseAt;
  if (!releaseAt) return;
  const tick = () => {
    const seconds = Math.max(0, Math.ceil((releaseAt - Date.now()) / 1000));
    const clock = `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`;
    wait.textContent = `Límite de archivos alcanzado. Puedes preparar otro video o audio en ${clock}.`;
    submit.querySelector('span').textContent = `Disponible en ${clock}`;
    if (!seconds) {
      clearInterval(waitTimer);
      releaseAt = 0;
      submit.disabled = false;
      submit.querySelector('span').textContent = 'Preparar descarga';
      wait.textContent = 'Ya puedes intentar preparar otro video o audio.';
      document.querySelector('#limits-availability').textContent = 'Venció un enlace anterior. El cupo se comprueba al preparar la descarga.';
    }
  };
  tick();
  waitTimer = setInterval(tick, 1000);
}

function show(message, kind = 'working') {
  panel.hidden = false;
  panel.dataset.kind = kind;
  statusText.textContent = message;
  progress.hidden = kind !== 'working';
  if (kind === 'working') progress.removeAttribute('value');
}

async function request(path, options = {}) {
  let response;
  try {
    response = await fetch(api + path, {
      ...options,
      headers: { 'Content-Type': 'application/json', 'X-Access-Code': accessCode },
      signal: AbortSignal.timeout(90000),
      cache: 'no-store',
    });
  } catch {
    throw new Error('No pudimos conectar. Revisa tu internet o intenta de nuevo en un minuto.');
  }
  if (response.status === 401) {
    accessCode = '';
    try { localStorage.removeItem('miquemi-access'); } catch {}
    if (!dialog.open) dialog.showModal();
    const error = new Error('Escribe tu clave para continuar.');
    error.accessRequired = true;
    throw error;
  }
  let data;
  try { data = await response.json(); } catch {
    throw new Error('El servicio no está disponible. Intenta de nuevo en un minuto.');
  }
  if (!response.ok) {
    if (data.limits) renderLimits(data.limits);
    throw new Error(data.error || 'No pudimos preparar el archivo. Intenta con otro enlace.');
  }
  return data;
}

document.querySelector('#paste').addEventListener('click', async () => {
  try {
    urlInput.value = (await navigator.clipboard.readText()).trim();
    urlInput.focus();
  } catch {
    urlInput.focus();
    show('Mantén presionado el campo del enlace y elige Pegar.', 'info');
  }
});

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  resumeAfterAccess = () => form.requestSubmit();
  submit.disabled = true;
  save.hidden = saveHelp.hidden = true;
  show('Conectando para preparar tu archivo. Si el servicio está dormido, puede tardar un minuto.');
  try {
    const limits = await request('/api/limits');
    renderLimits(limits);
    if (limits.retryAfter) throw new Error('Ya hay tres archivos listos. Abajo puedes ver cuánto falta para preparar otro video o audio.');
    const job = await request('/api/jobs', {
      method: 'POST',
      body: JSON.stringify({ url: urlInput.value.trim(), format: new FormData(form).get('format') }),
    });
    // ponytail: una descarga por página; sondeo simple para evitar conexiones persistentes.
    for (;;) {
      const result = await request('/api/jobs/' + job.id);
      if (result.state === 'error') throw new Error(result.message);
      if (result.state === 'ready') {
        show(result.title ? `Listo: ${result.title}` : '¡Tu archivo está listo!', 'ready');
        save.href = api + '/api/files/' + job.id;
        save.setAttribute('download', result.filename);
        save.hidden = saveHelp.hidden = false;
        statusText.focus();
        // El archivo ya está listo; un fallo al consultar el cupo no debe ocultarlo.
        try { renderLimits(await request('/api/limits')); } catch {}
        break;
      }
      show(result.message);
      if (result.progress !== null) progress.value = result.progress;
      await new Promise(resolve => setTimeout(resolve, 1500));
    }
  } catch (error) {
    show(error.message, error.accessRequired ? 'info' : 'error');
    if (!error.accessRequired) statusText.focus();
  } finally {
    submit.disabled = releaseAt > Date.now();
    if (!submit.disabled) submit.querySelector('span').textContent = 'Preparar descarga';
  }
});

document.querySelector('#access-form').addEventListener('submit', (event) => {
  event.preventDefault();
  accessCode = document.querySelector('#access-code').value.trim();
  try { localStorage.setItem('miquemi-access', accessCode); } catch {}
  dialog.close();
  const resume = resumeAfterAccess;
  resumeAfterAccess = () => form.requestSubmit();
  resume();
});
document.querySelector('#cancel-access').addEventListener('click', () => dialog.close());

const toolsPanel = document.querySelector('#tools-panel');
const toolsStatus = document.querySelector('#tools-status');
const verify = document.querySelector('#verify-tools');
const installButtons = [...document.querySelectorAll('[data-install]')];

function renderTools(data) {
  toolsPanel.hidden = !data.local;
  if (!data.local) return;
  document.querySelector('#access-help').textContent = 'Usa la clave local que aparece en la terminal donde iniciaste esta página.';
  document.querySelector('#hosting-quota').textContent = 'Modo local: usa la conexión de esta computadora. No aplica el cupo mensual de Render.';
  document.querySelector('#hosting-help').hidden = true;
  const ytReady = data.ytDlp.installed && data.youtube.installed;
  const ready = ytReady && data.ffmpeg.installed;
  document.querySelector('#tools-badge').textContent = ready ? 'Listas para descargar' : 'Faltan herramientas';
  if (!ready) toolsPanel.open = true;
  document.querySelector('#yt-state').textContent = data.ytDlp.installed ? `Instalado · ${data.ytDlp.version}` : 'No está instalado';
  document.querySelector('#ff-state').textContent = data.ffmpeg.installed ? 'Instalados y funcionando' : 'Falta FFmpeg o ffprobe';
  document.querySelector('#youtube-state').textContent = data.youtube.installed ? 'Soporte de YouTube listo.' : 'Para YouTube falta su motor. El botón de yt-dlp también lo instala.';
  const busy = data.installation.state === 'installing';
  verify.disabled = busy;
  installButtons[0].disabled = busy || ytReady;
  installButtons[0].textContent = ytReady ? 'Disponible' : data.ytDlp.installed ? 'Preparar YouTube' : 'Instalar yt-dlp';
  installButtons[1].disabled = busy || data.ffmpeg.installed;
  installButtons[1].textContent = data.ffmpeg.installed ? 'Disponible' : 'Instalar FFmpeg';
  toolsStatus.textContent = data.installation.message || (ready ? 'Todo listo. Esta página utiliza las herramientas de esta computadora.' : 'Instala lo que falta con los botones de arriba.');
}

async function verifyTools(quiet = false) {
  if (!quiet) toolsStatus.textContent = 'Verificando herramientas…';
  try {
    for (;;) {
      const data = await request('/api/tools');
      renderTools(data);
      if (!data.local || data.installation.state !== 'installing') return data;
      await new Promise(resolve => setTimeout(resolve, 1500));
    }
  } catch (error) {
    if (!quiet) toolsStatus.textContent = error.message;
    verify.disabled = false;
  }
}

async function installTool(tool) {
  resumeAfterAccess = () => installTool(tool);
  verify.disabled = true;
  installButtons.forEach(button => { button.disabled = true; });
  toolsStatus.textContent = 'Preparando instalación…';
  try {
    await request('/api/tools/install', { method: 'POST', body: JSON.stringify({ tool }) });
    await verifyTools();
  } catch (error) {
    await verifyTools(true);
    toolsStatus.textContent = error.message;
    verify.disabled = false;
  }
}

verify.addEventListener('click', () => verifyTools());
installButtons.forEach(button => button.addEventListener('click', () => installTool(button.dataset.install)));
verifyTools(true);
